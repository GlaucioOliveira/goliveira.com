﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Default : System.Web.UI.Page
{
    DB db = new DB();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            ddlDestaques.DataSource = db.SelectData("select * from destaque");
            ddlDestaques.DataBind();

            ddlPostagemInicial.DataSource = db.SelectData("select * from post_inicial");
            ddlPostagemInicial.DataBind();
        }
    }
    protected void btnAddDestaque_Click(object sender, EventArgs e)
    {
        Response.Redirect("Destaque.aspx?act=Add");
    }
    protected void btnEditDestaque_Click(object sender, EventArgs e)
    {
        Response.Redirect("Destaque.aspx?act=Edit&cod=" + ddlDestaques.SelectedValue);
    }
    protected void btnDelDestaque_Click(object sender, EventArgs e)
    {
        Response.Redirect("Destaque.aspx?act=Del&cod=" + ddlDestaques.SelectedValue);
    }
    protected void btnAddPostagemInicial_Click(object sender, EventArgs e)
    {
        Response.Redirect("PostagemInicial.aspx?act=Add");
    }
    protected void btnEditPostagemInicial_Click(object sender, EventArgs e)
    {
        Response.Redirect("PostagemInicial.aspx?act=Edit&cod=" + ddlPostagemInicial.SelectedValue);
    }
    protected void btnDelPostagemInicial_Click(object sender, EventArgs e)
    {
        Response.Redirect("PostagemInicial.aspx?act=Del&cod=" + ddlPostagemInicial.SelectedValue);
    }
}