﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Destaque : System.Web.UI.Page
{
    DB db = new DB();
    public DataTable Fields;
    public DataRow Row;
    public bool Edit, Delete;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsCallback)
        {
            Fields = db.SelectData("select * from destaque");

            if (getParam("act").ToLower().Equals("add"))
            {
                btnAdicionar.Visible = true;
            }

            if (getParam("act").ToLower().Equals("edit"))
            {
                Row = db.SelectData(string.Format("select * from destaque where cod = '{0}'", getParam("cod"))).Rows[0];
                Edit = true;
                btnEditar.Visible = true;
            }

            if (getParam("act").ToLower().Equals("del"))
            {
                Row = db.SelectData(string.Format("select * from destaque where cod = '{0}'", getParam("cod"))).Rows[0];
                Edit = true;
                Delete = true;
                btnDeletar.Visible = true;
            }
            Repeater1.DataSource = Fields.Columns;
            
            Repeater1.DataBind();
        }
    }

    public  string getParam(string s)
    {
        if (Request.Params[s] == null)
        {
            return "";
        }
        else
        {
            return Request.Params[s].ToString();
        }
    }

    public string getValue(string s)
    {
        if (Edit) 
        { 
            return Row[s].ToString(); 
        }

        else
        {
            return "";
        }

    }
    protected void btnAdicionar_Click(object sender, EventArgs e)
    {
       db.InsertData(String.Format("insert into destaque (link,link_img,img_alt) values ('{0}','{1}','{2}')",Request.Form["link"],Request.Form["link_img"],Request.Form["img_alt"]));
       Response.Redirect("Default.aspx");
    }

    protected void btnEditar_Click(object sender, EventArgs e)
    {
        if (Edit)
        {
            db.InsertData(String.Format("update destaque set link = '{0}',link_img ='{1}',img_alt='{2}' where cod = '{3}'", Request.Form["link"], Request.Form["link_img"], Request.Form["img_alt"],Request.Form["cod"]));
            Response.Redirect("Default.aspx");
        }
    }
    protected void btnDeletar_Click(object sender, EventArgs e)
    {
        if (Edit && Delete)
        {
            db.InsertData(String.Format("delete from destaque where cod = '{0}'", Request.Form["cod"]));
            Response.Redirect("Default.aspx");
        }
    }
}