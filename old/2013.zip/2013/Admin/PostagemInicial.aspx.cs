﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_PostagemInicial : System.Web.UI.Page
{
    DB db = new DB();
    public DataTable Fields;
    public DataRow Row;
    public bool Edit, Delete;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsCallback)
        {
            Fields = db.SelectData("select * from post_inicial");

            if (getParam("act").ToLower().Equals("add"))
            {
                btnAdicionar.Visible = true;
            }

            if (getParam("act").ToLower().Equals("edit"))
            {
                Row = db.SelectData(string.Format("select * from post_inicial where cod = '{0}'", getParam("cod"))).Rows[0];
                Edit = true;
                btnEditar.Visible = true;
            }

            if (getParam("act").ToLower().Equals("del"))
            {
                Row = db.SelectData(string.Format("select * from post_inicial where cod = '{0}'", getParam("cod"))).Rows[0];
                Edit = true;
                Delete = true;
                btnDeletar.Visible = true;
            }
            Repeater1.DataSource = Fields.Columns;

            Repeater1.DataBind();
        }
    }

    public string getParam(string s)
    {
        if (Request.Params[s] == null)
        {
            return "";
        }
        else
        {
            return Request.Params[s].ToString();
        }
    }

    public string getValue(string s)
    {
        if (Edit)
        {
            return Row[s].ToString();
        }

        else
        {
            return "";
        }

    }
    protected void btnAdicionar_Click(object sender, EventArgs e)
    {
        db.InsertData(String.Format("insert into post_inicial (titulo,conteudo,continuar_link,continuar_desc,cod) values ('{0}','{1}','{2}','{3}','{4}')", Request.Form["titulo"], Request.Form["conteudo"], Request.Form["continuar_link"], Request.Form["continuar_desc"], Request.Form["cod"]));
        Response.Redirect("Default.aspx");
    }

    protected void btnEditar_Click(object sender, EventArgs e)
    {
        if (Edit)
        {
            db.InsertData(String.Format("update post_inicial set titulo = '{0}',conteudo ='{1}',continuar_link='{2}',continuar_desc='{3}' where cod = '{4}'", Request.Form["titulo"], Request.Form["conteudo"], Request.Form["continuar_link"], Request.Form["continuar_desc"], Request.Form["cod"]));
            Response.Redirect("Default.aspx");
        }
    }
    protected void btnDeletar_Click(object sender, EventArgs e)
    {
        if (Edit && Delete)
        {
            db.InsertData(String.Format("delete from post_inicial where cod = '{0}'", Request.Form["cod"]));
            Response.Redirect("Default.aspx");
        }
    }
}