﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Compilation;
using System.Web.UI;

/// <summary>
/// Summary description for mainRouteHandler
/// </summary>
public class mainRouteHandler : IRouteHandler
{
    public IHttpHandler GetHttpHandler(RequestContext requestContext)
    {
        Dictionary<String, String> paths = new Dictionary<string, string>();
        paths.Add("resume", "~/site/resume.aspx");
        paths.Add("cv", "~/site/resume.aspx");
        paths.Add("curriculum", "~/site/resume.aspx");
        paths.Add("email", "~/email/index.aspx");

        string app = requestContext.RouteData.Values["aplicativo"] as string;

        try
        {
            HttpContext.Current.Items["cat"] = paths[app];
        }
        catch
        {
            HttpContext.Current.Items["cat"] = "diretório inválido!";
        }
        
        
        return BuildManager.CreateInstanceFromVirtualPath("~/redirect.aspx", typeof(Page)) as Page;
    }
}