﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for enumTipoUsuario
/// </summary>
public enum enumTipoUsuario
{
        Visitante = 1,
	    Usuario = 2,
        Administrador =3
}