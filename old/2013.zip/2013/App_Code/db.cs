﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using MySql.Data;
using MySql.Data.MySqlClient;
/// <summary>
/// Summary description for db
/// </summary>
public class DB
{

    MySqlConnection conn;

    public DB()
	{
	}

    public void CreateConnection(){
     conn = new MySqlConnection("Data Source=goliveirasite.db.7219272.hostedresource.com; Initial Catalog=goliveirasite; User ID=goliveirasite; Password='Gl123456';");
     conn.Open();
    }

    public DataTable SelectData(string sql)
    {
        CreateConnection();
        DataTable dt = new DataTable();
        MySqlDataAdapter dap = new MySqlDataAdapter(sql, conn);
        dap.Fill(dt);

        return dt;
    }

    public int InsertData(string sql)
    {
        CreateConnection();
        MySqlCommand cmd = new MySqlCommand(sql, conn);
        return cmd.ExecuteNonQuery();
    }
}