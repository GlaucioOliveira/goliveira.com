﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

/// <summary>
/// Summary description for PermissaoAttribute
/// </summary>
/// 
[AttributeUsage(AttributeTargets.Class)]
public sealed class PermissaoAttribute : Attribute
{
    public PermissaoAttribute(int TipoRequerido)
	{
        if (Usuario.TipoUsuario != TipoRequerido)
        {
            //TextWriter tw = TextWriter.Null;
            //HttpResponse r = new HttpResponse(tw);            
            //r.Redirect("AccessDenied.aspx");
            //HttpContext.Current.Reponse.Redirect("Errors.aspx"); // << produces
            HttpContext.Current.Session.Add("Permissao_Attb_urlOrigem", HttpContext.Current.Request.Url.AbsoluteUri);
            HttpContext.Current.Session.Add("Permissao_Attb_TipoRequerido", TipoRequerido);

            HttpContext.Current.Response.Redirect("~/AccessDenied.aspx");
        }
	}

    public bool isLogado { get; set; }
    //public static string TipoUsuario { get; set; }
    public DateTime TempoLogado { get; set; }
}