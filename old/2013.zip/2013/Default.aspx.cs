﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Security.Permissions;
using System.Security.Principal;



public partial class _Default : System.Web.UI.Page
{
    DB db = new DB();

    public DataTable posts,destaques;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsCallback) // se for o primeiro loading da página...
        {
            // Dev
            //posts = new DataTable();
            //destaques = new DataTable(); 

            //// Prod
            posts = db.SelectData("select * from post_inicial");
            destaques = db.SelectData("select * from destaque");
        }
    }


}